Smith Sim — Full Project (Client + Server)
========================================

What's included
- client/        -> Expo React Native mobile app (screens: Home, Memory, Settings)
- server/        -> Node.js + Express backend (chat endpoint)
- README.md      -> this file
- eas.json       -> EAS build profiles

Important notes BEFORE you run
- Do NOT commit your OpenAI API key. Add it to server/.env as OPENAI_API_KEY.
- Wake-word (Hey Smith) requires native Porcupine integration. This repo contains placeholders and instructions in README. You must add native modules and a .ppn file (from Picovoice) for on-device wake detection.
- The mobile client uses 'http://10.0.2.2:3000' as the server URL for Android emulator. Replace with your public server URL when testing on a real device.

Quickstart (Server)
1. cd server
2. npm install
3. create a .env file (copy .env.example) and set OPENAI_API_KEY and CLIENT_KEY.
4. npm start
Server runs at http://localhost:3000

Quickstart (Client)
1. cd client
2. npm install
3. npx expo start
4. Use Expo Go or emulator. On Android emulator, server URL 10.0.2.2:3000 resolves to host machine.

Porcupine Wake-word integration (summary)
- Sign up at Picovoice Console, create a keyword (e.g., 'Hey Smith'), and download the .ppn file for Android/iOS.
- Install @picovoice/porcupine-react-native and follow the native setup guide.
- Place the .ppn model in android/app/src/main/assets or iOS bundle and load it with PorcupineManager.
- After detection, start speech recognition (user consent) and call the /api/chat endpoint.

Building APK with EAS
1. npm install -g eas-cli
2. eas login
3. cd client
4. eas build -p android --profile production
See EAS docs for credentials and signing.

Security
- Never embed OPENAI_API_KEY in client.
- Use CLIENT_KEY and server-side auth for production and rate-limiting.

If you want, I can:
- Add Porcupine native plugin config files (Gradle changes) for Android (I will include guidance but NOT binary models).
- Prepare a test account on Render/Railway and deploy server for you.

