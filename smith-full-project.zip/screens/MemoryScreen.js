// screens/MemoryScreen.js
import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function MemoryScreen(){
  const [conv, setConv] = useState([]);
  useEffect(()=>{ load(); },[]);
  async function load(){ const s = await AsyncStorage.getItem('smith_conv'); if(s) setConv(JSON.parse(s)); }
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Memory Logs</Text>
      <FlatList data={conv.reverse()} keyExtractor={i=>i.id.toString()} renderItem={({item})=>(
        <View style={styles.item}><Text style={styles.role}>{item.role}</Text><Text style={styles.text}>{item.text}</Text><Text style={styles.time}>{new Date(item.t).toLocaleString()}</Text></View>
      )}/>
    </View>
  );
}
const styles = StyleSheet.create({
  container:{flex:1, padding:12, backgroundColor:'#000'},
  title:{color:'#0af', fontSize:22, fontWeight:'bold', marginBottom:10},
  item:{backgroundColor:'#111', padding:10, borderRadius:8, marginBottom:8},
  role:{color:'#0af', fontWeight:'bold'},
  text:{color:'#fff', marginTop:6},
  time:{color:'#888', fontSize:11, marginTop:6}
});
