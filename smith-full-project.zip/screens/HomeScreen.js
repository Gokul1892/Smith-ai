// screens/HomeScreen.js
import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet, ActivityIndicator } from 'react-native';
import * as Speech from 'expo-speech';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';

export default function HomeScreen({ navigation }) {
  const [listening, setListening] = useState(false);
  const [userText, setUserText] = useState('');
  const [reply, setReply] = useState('');
  const [loading, setLoading] = useState(false);
  const [conv, setConv] = useState([]);

  useEffect(() => {
    loadConversation();
  }, []);

  async function loadConversation(){
    const s = await AsyncStorage.getItem('smith_conv');
    if(s) setConv(JSON.parse(s));
  }

  async function saveAndPush(role, text){
    const m = { id: Date.now(), role, text, t: new Date().toISOString() };
    const updated = [...conv, m];
    setConv(updated);
    await AsyncStorage.setItem('smith_conv', JSON.stringify(updated));
  }

  async function sendText(text){
    if(!text) return;
    setLoading(true);
    await saveAndPush('user', text);
    try{
      const serverUrl = 'http://10.0.2.2:3000/api/chat'; // emulator default; replace with server URL or 127.0.0.1 tunneling
      const res = await axios.post(serverUrl, { messages: [{ role:'user', content: text }] }, { headers: { 'x-client-key': 'test-client-key' } });
      const r = res.data.reply || '(no reply)';
      setReply(r);
      await saveAndPush('assistant', r);
      Speech.speak(r);
    }catch(err){
      console.error(err);
      const errt = 'Error contacting server';
      setReply(errt);
      await saveAndPush('assistant', errt);
    }finally{
      setLoading(false);
    }
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>SMITH SIM</Text>
      <ScrollView style={styles.box}>
        <Text style={styles.label}>You said:</Text>
        <Text style={styles.text}>{userText || '---'}</Text>
        <Text style={styles.label}>Smith says:</Text>
        {loading ? <ActivityIndicator/> : <Text style={styles.text}>{reply || '---'}</Text>}
      </ScrollView>

      <View style={styles.controls}>
        <TouchableOpacity style={styles.btn} onPress={() => { /* placeholder wake-word simulate */ sendText('Hello Smith'); }}>
          <Text style={styles.btnText}>Wake (simulate)</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.btn} onPress={() => sendText('Tell me a joke')}>
          <Text style={styles.btnText}>Ask</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.btnSecondary} onPress={()=>navigation.navigate('Memory')}>
          <Text style={styles.btnText}>Memory</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.btnSecondary} onPress={()=>navigation.navigate('Settings')}>
          <Text style={styles.btnText}>Settings</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container:{flex:1, padding:18, backgroundColor:'#040406'},
  title:{color:'#0af', fontSize:26, fontWeight:'bold', textAlign:'center', marginBottom:12},
  box:{flex:1, backgroundColor:'#111', borderRadius:12, padding:12, marginBottom:12},
  label:{color:'#0af', marginTop:6},
  text:{color:'#fff', marginTop:4},
  controls:{flexDirection:'row', justifyContent:'space-between', gap:8},
  btn:{backgroundColor:'#0af', padding:12, borderRadius:10},
  btnSecondary:{backgroundColor:'#333', padding:12, borderRadius:10},
  btnText:{color:'#000', fontWeight:'bold'}
});
