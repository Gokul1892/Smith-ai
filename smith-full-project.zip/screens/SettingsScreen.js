// screens/SettingsScreen.js
import React, { useState, useEffect } from 'react';
import { View, Text, Switch, StyleSheet, TouchableOpacity } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function SettingsScreen(){
  const [voiceOn, setVoiceOn] = useState(true);
  const [personality, setPersonality] = useState(50);
  useEffect(()=>{ load(); },[]);
  async function load(){
    const s = await AsyncStorage.getItem('smith_settings');
    if(s){
      const o = JSON.parse(s);
      setVoiceOn(o.voiceOn); setPersonality(o.personality||50);
    }
  }
  async function save(){
    await AsyncStorage.setItem('smith_settings', JSON.stringify({ voiceOn, personality }));
    alert('Saved');
  }
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Settings</Text>
      <View style={styles.row}><Text style={styles.label}>Voice</Text><Switch value={voiceOn} onValueChange={setVoiceOn}/></View>
      <View style={styles.row}><Text style={styles.label}>Personality: {personality}</Text></View>
      <TouchableOpacity style={styles.saveBtn} onPress={save}><Text style={styles.saveText}>Save</Text></TouchableOpacity>
      <Text style={styles.note}>Note: Wake-word requires native integration (see README).</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container:{flex:1, padding:12, backgroundColor:'#000'},
  title:{color:'#0af', fontSize:22, fontWeight:'bold', marginBottom:10},
  row:{flexDirection:'row', justifyContent:'space-between', alignItems:'center', marginVertical:10},
  label:{color:'#fff'},
  saveBtn:{backgroundColor:'#0af', padding:12, borderRadius:8, marginTop:20},
  saveText:{color:'#000', fontWeight:'bold', textAlign:'center'},
  note:{color:'#888', marginTop:12}
});
