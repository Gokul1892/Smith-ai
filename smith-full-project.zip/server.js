// server/server.js
require('dotenv').config();
const express = require('express');
const fs = require('fs');
const path = require('path');
const { OpenAI } = require('openai');
const rateLimit = require('express-rate-limit');
const app = express();
app.use(express.json({ limit: '200kb' }));
app.use(rateLimit({ windowMs: 15*60*1000, max:200 }));

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY || '' });
const CLIENT_KEY = process.env.CLIENT_KEY || 'test-client-key';
function requireClientKey(req,res,next){
  const key = req.headers['x-client-key'];
  if(!key || key !== CLIENT_KEY) return res.status(401).json({ error: 'Unauthorized' });
  next();
}

app.post('/api/chat', requireClientKey, async (req,res)=> {
  try{
    const { messages } = req.body;
    if(!messages) return res.status(400).json({ error:'messages required' });

    // Build simple prompt: include system if present
    const response = await openai.responses.create({
      model: 'gpt-4o-mini',
      input: messages
    });

    const reply = response.output?.[0]?.content?.[0]?.text || response.output_text || 'No reply';
    return res.json({ reply });
  }catch(err){
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// TTS proxy - simple example using OpenAI TTS endpoint if available
app.post('/api/tts', requireClientKey, async (req,res)=>{
  try{
    const { text, voice='alloy' } = req.body;
    if(!text) return res.status(400).json({ error:'text required' });
    // For demo: return a small TTS via client side is recommended. Here we return a short JSON with text.
    return res.json({ tts: { text } });
  }catch(err){
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=> console.log('Server listening on', PORT));
